# Crux release path

This project is configured to target Android 16 (API 36), the Google Play requirement for new mobile apps submitted after August 31, 2026.

## Cloud build
Every push to `main`/`master` builds:
- an installable debug APK for direct device testing;
- an unsigned release AAB for release-pipeline validation.

## Before Google Play production
1. Choose the permanent Android application ID before the first Play listing.
2. Create and securely retain an upload keystore.
3. Configure release signing through GitHub Actions secrets (never commit the keystore/passwords).
4. Build the signed AAB and upload it to Play Console.
5. Complete store listing, privacy/data-safety declarations, content rating and testing requirements.

Do not add local LLM/model integration until the deterministic MVP has been used on real exported chats and the extraction quality has been validated.
