package com.crux.app

import com.crux.app.whatsapp.ContextReducer
import com.crux.app.whatsapp.Message
import com.crux.app.whatsapp.NoiseFilter
import com.crux.app.whatsapp.WhatsAppParser
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.TimeUnit

class ParserFilterReducerTest {

    private val parser = WhatsAppParser()
    private val filter = NoiseFilter()

    // ── Parser ───────────────────────────────────────────────────────────────

    @Test
    fun `parse standard Android format`() {
        val msgs = parser.parse("15/03/2024, 19:00 - Priya: Hello world")
        assertEquals(1, msgs.size)
        assertEquals("Priya", msgs[0].sender)
        assertEquals("Hello world", msgs[0].text)
    }

    @Test
    fun `parse iOS bracket format`() {
        val msgs = parser.parse("[15/03/2024, 19:00:00] Priya: Hello iOS")
        assertEquals(1, msgs.size)
        assertEquals("Priya", msgs[0].sender)
        assertEquals("Hello iOS", msgs[0].text)
    }

    @Test
    fun `multiline message appended correctly`() {
        val input = """
            15/03/2024, 19:00 - Raj: First line
            second line
            third line
            15/03/2024, 19:01 - Priya: Next message
        """.trimIndent()
        val msgs = parser.parse(input)
        assertEquals(2, msgs.size)
        assertTrue(msgs[0].text.contains("second line"))
        assertTrue(msgs[0].text.contains("third line"))
    }

    @Test
    fun `system message flagged isSystem`() {
        val msgs = parser.parse("15/03/2024, 19:00 - Messages and calls are end-to-end encrypted. No one outside...")
        assertTrue(msgs[0].isSystem)
    }

    @Test
    fun `assigns stable sequential IDs from 0`() {
        val input = "15/03/2024, 19:00 - A: one\n15/03/2024, 19:01 - B: two\n15/03/2024, 19:02 - C: three"
        val msgs = parser.parse(input)
        assertEquals(listOf(0, 1, 2), msgs.map { it.id })
    }

    @Test
    fun `empty input returns empty list`() {
        assertEquals(0, parser.parse("").size)
        assertEquals(0, parser.parse("   \n\n").size)
    }

    @Test
    fun `parse 12-hour time with am-pm`() {
        val msgs = parser.parse("15/03/2024, 7:05 pm - Raj: Evening message")
        assertEquals(1, msgs.size)
        assertEquals("Raj", msgs[0].sender)
    }

    // ── Noise filter — exact removal ──────────────────────────────────────────

    private fun msg(text: String, id: Int = 0, isSystem: Boolean = false) =
        Message(id, 0L, "Sender", text, 0, isSystem)

    @Test fun `removes standalone ok`() { assertTrue(filter.shouldRemove(msg("ok"))) }
    @Test fun `removes standalone thanks`() { assertTrue(filter.shouldRemove(msg("thanks"))) }
    @Test fun `removes standalone good morning`() { assertTrue(filter.shouldRemove(msg("good morning"))) }
    @Test fun `removes thumbs up emoji`() { assertTrue(filter.shouldRemove(msg("👍"))) }
    @Test fun `removes compound emoji`() { assertTrue(filter.shouldRemove(msg("😊🙏❤️"))) }
    @Test fun `removes media omitted`() { assertTrue(filter.shouldRemove(msg("<media omitted>"))) }
    @Test fun `removes system messages`() { assertTrue(filter.shouldRemove(msg("something", isSystem = true))) }

    @Test
    fun `keeps substantive message starting with ok`() {
        assertFalse(filter.shouldRemove(msg("ok sounds great, dinner at 8:30pm")))
    }

    @Test
    fun `keeps thanks followed by context`() {
        assertFalse(filter.shouldRemove(msg("thanks for booking the table!")))
    }

    @Test
    fun `keeps short specific message`() {
        assertFalse(filter.shouldRemove(msg("8:30pm works")))
    }

    @Test
    fun `100 percent noise conversation filter returns empty list`() {
        val allNoise = listOf(
            msg("ok", 0), msg("👍", 1), msg("thanks", 2),
            msg("gm", 3), msg("<media omitted>", 4),
            msg("yes", 5), msg("no", 6), msg("sure", 7),
            msg("nice", 8), msg("👌", 9)
        )
        val result = filter.filter(allNoise)
        assertTrue("Expected empty after 100% noise filter, got ${result.size}", result.isEmpty())
    }

    // ── Context reducer ───────────────────────────────────────────────────────

    private val reducer = ContextReducer(maxChars = 1000)

    private fun timedMsg(id: Int, ageHours: Long, text: String = "A meaningful message here."): Message {
        val now = 1_710_000_000_000L // fixed epoch to avoid flakiness
        return Message(id, now - TimeUnit.HOURS.toMillis(ageHours), "Sender", text, 0)
    }

    @Test
    fun `returns empty for empty input`() {
        assertTrue(reducer.reduce(emptyList()).messages.isEmpty())
    }

    @Test
    fun `selects last 24h when enough messages exist`() {
        val messages = (0..9).map { timedMsg(it, ageHours = it.toLong()) }
        val result = reducer.reduce(messages)
        assertEquals("last 24 hours", result.timeRange)
        assertTrue(result.messages.isNotEmpty())
    }

    @Test
    fun `expands to 3 days when 24h has too few messages`() {
        val messages = listOf(timedMsg(0, 47), timedMsg(1, 46), timedMsg(2, 45))
        val result = reducer.reduce(messages)
        assertEquals("last 3 days", result.timeRange)
    }

    @Test
    fun `output is chronologically ordered`() {
        val messages = listOf(timedMsg(2, 3), timedMsg(0, 1), timedMsg(1, 2))
        val result = reducer.reduce(messages)
        val ts = result.messages.map { it.timestamp }
        assertEquals(ts, ts.sorted())
    }

    @Test
    fun `applies char budget`() {
        val bigMessages = (0..99).map { timedMsg(it, ageHours = it.toLong(), text = "X".repeat(50)) }
        val result = reducer.reduce(bigMessages)
        val totalChars = result.messages.sumOf { it.text.length }
        assertTrue("Char total $totalChars exceeds budget", totalChars <= 1200)
    }
}
