package com.crux.app

import com.crux.app.crux.*
import com.crux.app.whatsapp.Message
import com.crux.app.whatsapp.WhatsAppParser
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class ExtractorEngineTest {

    private val engine = DeterministicCruxEngine()
    private val parser = WhatsAppParser()

    private fun msgs(vararg texts: String): List<Message> =
        texts.mapIndexed { i, t -> Message(i, 1_710_000_000_000L + i * 60_000L, "Sender$i", t, 0) }

    // ── Date extractor ────────────────────────────────────────────────────────

    @Test
    fun `extracts dd slash mm slash yyyy`() {
        val items = DateExtractor.extract(msgs("Meeting on 20/03/2024"))
        assertTrue(items.any { "20/03/2024" in it.text })
    }

    @Test
    fun `extracts relative date tomorrow`() {
        val items = DateExtractor.extract(msgs("Let's meet tomorrow"))
        assertTrue(items.any { "tomorrow" in it.text.lowercase() })
    }

    @Test
    fun `extracts day name Monday`() {
        val items = DateExtractor.extract(msgs("See you Monday"))
        assertTrue(items.any { "Monday" in it.text })
    }

    @Test
    fun `extracts time with am pm`() {
        val items = DateExtractor.extract(msgs("Dinner at 8:30pm"))
        assertTrue(items.any { "8:30pm" in it.text.lowercase() || "8:30" in it.text })
    }

    // ── Amount extractor ──────────────────────────────────────────────────────

    @Test
    fun `extracts rupee amount`() {
        val items = AmountExtractor.extract(msgs("Total is Rs. 1200"))
        assertTrue(items.any { "1200" in it.text })
    }

    @Test
    fun `extracts rupee symbol`() {
        val items = AmountExtractor.extract(msgs("Pay ₹500 each"))
        assertTrue(items.any { "500" in it.text })
    }

    @Test
    fun `extracts dollar amount`() {
        val items = AmountExtractor.extract(msgs("It costs \$200"))
        assertTrue(items.any { "200" in it.text })
    }

    // ── URL extractor ─────────────────────────────────────────────────────────

    @Test
    fun `extracts https url`() {
        val items = UrlExtractor.extract(msgs("Check https://maps.google.com for directions"))
        assertTrue(items.any { "https://maps.google.com" in it.text })
    }

    // ── Question extractor ────────────────────────────────────────────────────

    @Test
    fun `extracts substantive question`() {
        val items = QuestionExtractor.extract(msgs("Are we meeting tonight?", "ok"))
        assertEquals(1, items.size)
        assertTrue("Are we meeting tonight?" in items[0].text)
    }

    @Test
    fun `ignores very short question`() {
        val items = QuestionExtractor.extract(msgs("ok?"))
        assertTrue(items.isEmpty())
    }

    // ── Engine: source IDs preserved ─────────────────────────────────────────

    @Test
    fun `dates carry source message ids`() = runTest {
        val messages = msgs("Let's meet at 8:30pm tonight")
        val result = engine.process(messages)
        val datesWithIds = result.dates.filter { it.sourceMessageIds.isNotEmpty() }
        assertTrue("Expected dates with sourceMessageIds", datesWithIds.isNotEmpty())
    }

    @Test
    fun `amounts carry source message ids`() = runTest {
        val messages = msgs("Total cost is Rs. 1200")
        val result = engine.process(messages)
        val amountsWithIds = result.amounts.filter { it.sourceMessageIds.isNotEmpty() }
        assertTrue("Expected amounts with sourceMessageIds", amountsWithIds.isNotEmpty())
    }

    // ── 100% noise → nothing found ────────────────────────────────────────────

    @Test
    fun `100 percent noise input produces empty result`() = runTest {
        val noiseMessages = listOf(
            Message(0, 1_710_000_000_000L, "A", "ok", 0),
            Message(1, 1_710_000_060_000L, "B", "thanks", 0),
            Message(2, 1_710_000_120_000L, "A", "👍", 0),
            Message(3, 1_710_000_180_000L, "B", "gm", 0)
        )
        val result = engine.process(noiseMessages)
        assertTrue(result.currentSituation.isEmpty())
        assertTrue(result.decisions.isEmpty())
        assertTrue(result.actions.isEmpty())
        assertTrue(result.dates.isEmpty())
        assertTrue(result.amounts.isEmpty())
        assertTrue(result.openQuestions.isEmpty())
    }

    // ── Changed decision: latest state wins ───────────────────────────────────

    @Test
    fun `changed decision shows latest confirmed state`() = runTest {
        val conversation = """
            15/03/2024, 10:00 - Priya: Let's meet at Starbucks at 5pm today
            15/03/2024, 10:02 - Raj: ok confirmed, Starbucks 5pm
            15/03/2024, 14:30 - Priya: Actually Starbucks is closed today for renovation
            15/03/2024, 14:32 - Raj: Yes, confirmed. Cafe Coffee Day at 5pm then.
            15/03/2024, 14:33 - Priya: Great, see you there!
        """.trimIndent()
        val messages = parser.parse(conversation)
        val result = engine.process(messages)

        // Decisions list should include the Cafe Coffee Day confirmation
        val decisionTexts = result.decisions.map { it.text.lowercase() }
        assertTrue(
            "Expected Cafe Coffee Day in decisions, got: $decisionTexts",
            decisionTexts.any { "cafe coffee day" in it }
        )

        // The latest decision (Cafe Coffee Day) should appear after Starbucks in the list
        val starbucksIndex = decisionTexts.indexOfFirst { "starbucks" in it }
        val cafeCoffeeDayIndex = decisionTexts.indexOfFirst { "cafe coffee day" in it }
        if (starbucksIndex >= 0 && cafeCoffeeDayIndex >= 0) {
            assertTrue(
                "Cafe Coffee Day decision should appear after Starbucks (later in time)",
                cafeCoffeeDayIndex > starbucksIndex
            )
        }
    }

    // ── People: only from referenced messages ─────────────────────────────────

    @Test
    fun `people list only contains senders from referenced messages`() = runTest {
        val messages = listOf(
            Message(0, 1_710_000_000_000L, "Priya", "ok", 0),
            Message(1, 1_710_000_060_000L, "Raj", "Table booked at 8:30pm confirmed", 0),
            Message(2, 1_710_000_120_000L, "Anita", "gm", 0)
        )
        val result = engine.process(messages)
        // Raj is referenced (confirmed message with date/decision)
        // Priya and Anita only sent noise — should NOT be in people unless also in a referenced message
        if (result.people.isNotEmpty()) {
            assertTrue(
                "People should not include Priya (only noise sender), got: ${result.people}",
                result.people.contains("Raj")
            )
        }
    }
}
