package com.crux.app.crux

import com.crux.app.whatsapp.Message

// ── Result types ─────────────────────────────────────────────────────────────

interface CruxEngine {
    suspend fun process(messages: List<Message>): CruxResult
}

data class CruxResult(
    val currentSituation: List<CruxItem> = emptyList(),
    val decisions: List<CruxItem> = emptyList(),
    val actions: List<ActionItem> = emptyList(),
    val dates: List<CruxItem> = emptyList(),
    val amounts: List<CruxItem> = emptyList(),
    val openQuestions: List<CruxItem> = emptyList(),
    val people: List<String> = emptyList(),
    val importantFacts: List<CruxItem> = emptyList(),
    val debugInfo: DebugInfo = DebugInfo()
)

data class CruxItem(
    val text: String,
    val sourceMessageIds: List<Int> = emptyList()
)

data class ActionItem(
    val person: String,
    val action: String,
    val sourceMessageIds: List<Int> = emptyList()
)

data class DebugInfo(
    val totalMessages: Int = 0,
    val afterFilter: Int = 0,
    val selectedMessages: Int = 0,
    val timeRange: String = ""
)

// ── Extractors ────────────────────────────────────────────────────────────────

object DateExtractor {
    private val patterns = listOf(
        Regex("""\b(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})\b"""),
        Regex("""\b(tomorrow|today|yesterday|tonight)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|week|month))\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?))\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(\d{1,2}:\d{2}\s*(?:am|pm))\b""", RegexOption.IGNORE_CASE)
    )

    fun extract(messages: List<Message>): List<CruxItem> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<CruxItem>()
        for (msg in messages) {
            for (pattern in patterns) {
                pattern.findAll(msg.text).forEach { match ->
                    val text = match.value.trim()
                    if (seen.add(text.lowercase())) {
                        result.add(CruxItem(text, listOf(msg.id)))
                    }
                }
            }
        }
        return result.take(10)
    }
}

object AmountExtractor {
    private val patterns = listOf(
        Regex("""(?:Rs\.?|INR|₹)\s*(\d[\d,]*(?:\.\d+)?)\b"""),
        Regex("""\$\s*(\d[\d,]*(?:\.\d+)?)\b"""),
        Regex("""€\s*(\d[\d,]*(?:\.\d+)?)\b"""),
        Regex("""£\s*(\d[\d,]*(?:\.\d+)?)\b"""),
        Regex("""\b(\d[\d,]*(?:\.\d+)?)\s*(?:rupees?|dollars?|euros?|pounds?|lakhs?|crores?)\b""", RegexOption.IGNORE_CASE)
    )

    fun extract(messages: List<Message>): List<CruxItem> {
        val seen = mutableSetOf<String>()
        val result = mutableListOf<CruxItem>()
        for (msg in messages) {
            for (pattern in patterns) {
                pattern.findAll(msg.text).forEach { match ->
                    val text = match.value.trim()
                    if (seen.add(text.lowercase())) {
                        result.add(CruxItem(text, listOf(msg.id)))
                    }
                }
            }
        }
        return result.take(10)
    }
}

object UrlExtractor {
    private val URL_PATTERN = Regex("""https?://[^\s<>"{}|\\^`\[\]]+""")

    fun extract(messages: List<Message>): List<CruxItem> =
        messages.flatMap { msg ->
            URL_PATTERN.findAll(msg.text).map { CruxItem(it.value, listOf(msg.id)) }
        }.distinctBy { it.text }.take(8)
}

object ActionPhraseExtractor {
    private val TRIGGERS = listOf(
        Regex("""(?<![a-z])([A-Z][a-zA-Z]+)\s+will\s+(\w[\w\s]{3,50}?)(?=[.!?,\n]|$)"""),
        Regex("""(?<![a-z])(I|we|you)\s+will\s+(\w[\w\s]{3,50}?)(?=[.!?,\n]|$)""", RegexOption.IGNORE_CASE),
        Regex("""(?:I'll|I will|we'll|we will)\s+(\w[\w\s]{3,50}?)(?=[.!?,\n]|$)""", RegexOption.IGNORE_CASE),
        Regex("""(?:need to|going to|let's|please|can you|should)\s+(\w[\w\s]{3,50}?)(?=[.!?,\n]|$)""", RegexOption.IGNORE_CASE)
    )

    fun extract(messages: List<Message>): List<Pair<String, Int>> {
        val result = mutableListOf<Pair<String, Int>>()
        for (msg in messages) {
            for (pattern in TRIGGERS) {
                pattern.findAll(msg.text).forEach { match ->
                    val phrase = match.value.trim()
                    if (phrase.length in 8..120) {
                        result.add(Pair(phrase, msg.id))
                    }
                }
            }
        }
        return result.distinctBy { it.first.lowercase() }.take(10)
    }
}

object QuestionExtractor {
    fun extract(messages: List<Message>): List<CruxItem> =
        messages
            .filter { it.text.trim().endsWith("?") && it.text.trim().length > 10 }
            .map { CruxItem(it.text.trim(), listOf(it.id)) }
            .take(6)
}
