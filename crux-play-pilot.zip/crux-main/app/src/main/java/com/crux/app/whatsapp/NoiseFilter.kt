package com.crux.app.whatsapp

class NoiseFilter {

    companion object {
        // Exact full-message matches only. A message is noise ONLY if its entire
        // trimmed text matches one of these — never if it merely contains these words.
        private val LOW_INFO_EXACT = setOf(
            "ok", "okay", "k", "kk", "kkk",
            "thanks", "thank you", "ty", "tq", "thx", "thanku", "thnx",
            "welcome", "yw", "np", "no problem",
            "good morning", "gm", "good night", "gn",
            "good afternoon", "good evening",
            "hi", "hello", "hey", "hii", "hiii", "heyy",
            "bye", "goodbye", "cya", "ttyl",
            "yes", "no", "yep", "nope", "yeah", "nah", "yup",
            "haha", "hehe", "lol", "lmao",
            "hmm", "hm", "oh", "ah", "uh", "umm",
            "done", "sure", "noted", "ok done", "ok noted",
            "nice", "great", "cool", "wow", "okay cool", "ok cool"
        )

        private val MEDIA_OMITTED = setOf(
            "<media omitted>",
            "image omitted", "video omitted", "audio omitted",
            "sticker omitted", "gif omitted", "document omitted",
            "contact card omitted"
        )
    }

    fun filter(messages: List<Message>): List<Message> = messages.filterNot { shouldRemove(it) }

    fun shouldRemove(message: Message): Boolean {
        if (message.isSystem) return true
        val trimmed = message.text.trim()
        if (trimmed.isEmpty()) return true
        val lower = trimmed.lowercase()
        if (lower in LOW_INFO_EXACT) return true
        if (lower in MEDIA_OMITTED) return true
        if (isEmojiOrSymbolOnly(trimmed)) return true
        return false
    }

    // A message is emoji/symbol-only if it contains no letters or digits at all.
    private fun isEmojiOrSymbolOnly(text: String): Boolean = text.none { it.isLetterOrDigit() }
}
