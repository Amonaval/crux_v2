package com.crux.app.whatsapp

import java.util.Calendar
import java.util.TimeZone

data class Message(
    val id: Int,
    val timestamp: Long,
    val sender: String,
    val text: String,
    val startLine: Int,
    val isSystem: Boolean = false
)

class WhatsAppParser {

    companion object {
        // Android: "15/03/2024, 19:00 - Name: text" or "15/3/24, 7:05 pm - Name: text"
        private val ANDROID_HEADER = Regex(
            """^(\d{1,2})/(\d{1,2})/(\d{2,4}),\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*([aApP][mM])?\s*-\s+(.+?):\s*(.*)$"""
        )
        // iOS: "[15/03/2024, 19:00:00] Name: text"
        private val IOS_HEADER = Regex(
            """^\[(\d{1,2})/(\d{1,2})/(\d{2,4}),\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*([aApP][mM])?\]\s+(.+?):\s*(.*)$"""
        )

        private val SYSTEM_KEYWORDS = listOf(
            "end-to-end encrypted",
            "messages and calls are end-to-end",
            "added ",
            " left",
            " removed ",
            "changed the subject",
            "changed this group",
            "created group",
            "security code",
            "changed their phone number"
        )
    }

    private data class PendingMessage(
        val timestamp: Long,
        val sender: String,
        val text: String,
        val startLine: Int,
        val isSystem: Boolean
    )

    fun parse(content: String): List<Message> {
        if (content.isBlank()) return emptyList()
        val lines = content.lines()
        val result = mutableListOf<Message>()
        var pending: PendingMessage? = null
        var idCounter = 0

        fun flush() {
            pending?.let {
                result.add(Message(idCounter++, it.timestamp, it.sender, it.text.trim(), it.startLine, it.isSystem))
                pending = null
            }
        }

        for ((lineIndex, line) in lines.withIndex()) {
            val parsed = tryParseHeader(line, lineIndex)
            if (parsed != null) {
                flush()
                pending = parsed
            } else if (pending != null && line.isNotBlank()) {
                // Continuation of previous message
                pending = pending!!.copy(text = pending!!.text + "\n" + line)
            }
        }
        flush()
        return result
    }

    private fun tryParseHeader(line: String, lineIndex: Int): PendingMessage? {
        val androidMatch = ANDROID_HEADER.matchEntire(line)
        if (androidMatch != null) {
            val (day, month, year, hour, minute, ampm, sender, text) = androidMatch.destructured
            val ts = buildTimestamp(day.toIntOrNull() ?: return null,
                month.toIntOrNull() ?: return null,
                year.toIntOrNull() ?: return null,
                hour.toIntOrNull() ?: return null,
                minute.toIntOrNull() ?: return null,
                ampm)
            val isSystem = isSystemMessage(sender, text)
            return PendingMessage(ts, if (isSystem) "" else sender, text, lineIndex, isSystem)
        }

        val iosMatch = IOS_HEADER.matchEntire(line)
        if (iosMatch != null) {
            val (day, month, year, hour, minute, ampm, sender, text) = iosMatch.destructured
            val ts = buildTimestamp(day.toIntOrNull() ?: return null,
                month.toIntOrNull() ?: return null,
                year.toIntOrNull() ?: return null,
                hour.toIntOrNull() ?: return null,
                minute.toIntOrNull() ?: return null,
                ampm)
            val isSystem = isSystemMessage(sender, text)
            return PendingMessage(ts, if (isSystem) "" else sender, text, lineIndex, isSystem)
        }

        return null
    }

    private fun buildTimestamp(day: Int, month: Int, year: Int, hour: Int, minute: Int, ampm: String): Long {
        return try {
            val cal = Calendar.getInstance(TimeZone.getDefault())
            val fullYear = if (year < 100) 2000 + year else year
            var h = hour
            if (ampm.lowercase() == "pm" && h != 12) h += 12
            if (ampm.lowercase() == "am" && h == 12) h = 0
            cal.set(fullYear, month - 1, day, h, minute, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.timeInMillis
        } catch (e: Exception) {
            0L
        }
    }

    private fun isSystemMessage(sender: String, text: String): Boolean {
        val combined = "$sender $text".lowercase()
        return SYSTEM_KEYWORDS.any { combined.contains(it.lowercase()) }
    }
}
