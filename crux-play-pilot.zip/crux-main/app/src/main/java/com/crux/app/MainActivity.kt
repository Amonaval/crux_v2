package com.crux.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.crux.app.ui.HomeScreen
import com.crux.app.ui.MainViewModel
import com.crux.app.ui.ProcessingScreen
import com.crux.app.ui.ResultScreen
import com.crux.app.ui.UiState

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) { /* WhatsApp may not grant persistable */ }
                viewModel.processUri(this, uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                val uiState by viewModel.uiState.collectAsState()

                when (val state = uiState) {
                    is UiState.Idle -> HomeScreen(
                        onSelectFile = { openFilePicker() },
                        onTrySample = { viewModel.loadSample(this) }
                    )
                    is UiState.Processing -> ProcessingScreen(state.stage)
                    is UiState.Success -> ResultScreen(
                        result = state.result,
                        getMessagesByIds = viewModel::getMessagesByIds,
                        onNew = viewModel::reset
                    )
                    is UiState.Error -> HomeScreen(
                        onSelectFile = { openFilePicker() },
                        onTrySample = { viewModel.loadSample(this) },
                        error = state.message
                    )
                }
            }
        }

        if (savedInstanceState == null) {
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                when {
                    uri != null -> viewModel.processUri(this, uri)
                    text != null && text.length > 50 -> viewModel.processText(text)
                }
            }
            Intent.ACTION_VIEW -> intent.data?.let { viewModel.processUri(this, it) }
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        filePicker.launch(intent)
    }
}
