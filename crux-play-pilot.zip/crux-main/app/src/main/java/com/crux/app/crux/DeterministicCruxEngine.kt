package com.crux.app.crux

import com.crux.app.whatsapp.Message

class DeterministicCruxEngine : CruxEngine {

    private val DECISION_KEYWORDS = Regex(
        """\b(decided|confirmed|booked|going with|we'll go|it's set|let's go with|we are going|it's confirmed)\b""",
        RegexOption.IGNORE_CASE
    )

    override suspend fun process(messages: List<Message>): CruxResult {
        if (messages.isEmpty()) return CruxResult()

        val dates = DateExtractor.extract(messages)
        val amounts = AmountExtractor.extract(messages)
        val urls = UrlExtractor.extract(messages)
        val questions = QuestionExtractor.extract(messages)
        val actionPhrases = ActionPhraseExtractor.extract(messages)

        // Actions: pair each phrase with its originating sender
        val actions = actionPhrases.map { (phrase, msgId) ->
            val sender = messages.find { it.id == msgId }?.sender ?: ""
            ActionItem(person = sender, action = phrase, sourceMessageIds = listOf(msgId))
        }

        // Decisions: keep ALL matching messages (latest state visible at bottom of result)
        val decisions = messages
            .filter { DECISION_KEYWORDS.containsMatchIn(it.text) }
            .map { CruxItem(it.text.take(200), listOf(it.id)) }

        // People: ONLY senders of messages referenced in extracted items
        val referencedIds = (dates + amounts + urls + decisions)
            .flatMap { it.sourceMessageIds }
            .toMutableSet()
        referencedIds.addAll(actions.flatMap { it.sourceMessageIds })
        val people = messages
            .filter { it.id in referencedIds && it.sender.isNotBlank() }
            .map { it.sender }
            .distinct()

        val nothingFound = dates.isEmpty() && amounts.isEmpty() && decisions.isEmpty()
                && actions.isEmpty() && questions.isEmpty() && urls.isEmpty()

        val situation = if (nothingFound) emptyList()
        else messages.filter { it.text.length > 20 }.takeLast(5)
            .map { CruxItem(it.text.take(150), listOf(it.id)) }

        return CruxResult(
            currentSituation = situation,
            decisions = decisions,
            actions = actions,
            dates = dates,
            amounts = amounts,
            openQuestions = questions,
            people = people,
            importantFacts = urls
        )
    }
}
