package com.crux.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.crux.app.crux.ActionItem
import com.crux.app.crux.CruxItem
import com.crux.app.crux.CruxResult
import com.crux.app.whatsapp.Message

private val Accent = Color(0xFF1A73E8)

// ── Home Screen ───────────────────────────────────────────────────────────────

@Composable
fun HomeScreen(
    onSelectFile: () -> Unit,
    onTrySample: () -> Unit,
    error: String? = null
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "crux",
            fontSize = 56.sp,
            fontWeight = FontWeight.Bold,
            color = Accent,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Turn conversations into what matters.",
            fontSize = 16.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(48.dp))
        Button(
            onClick = onSelectFile,
            modifier = Modifier.fillMaxWidth(0.8f),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) {
            Text("Select WhatsApp export", fontSize = 15.sp)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = onTrySample,
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Text("Try sample conversation", fontSize = 15.sp)
        }
        if (error != null) {
            Spacer(Modifier.height(24.dp))
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Processing Screen ─────────────────────────────────────────────────────────

@Composable
fun ProcessingScreen(stage: String) {
    val stages = listOf(
        "Reading conversation",
        "Parsing messages",
        "Removing noise",
        "Finding current context",
        "Extracting Crux"
    )
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = Accent, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(32.dp))
        stages.forEach { s ->
            val isCurrent = s == stage
            val isPast = stages.indexOf(s) < stages.indexOf(stage)
            Text(
                text = if (isPast) "✓ $s" else if (isCurrent) "▶ $s" else "  $s",
                fontSize = 14.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    isPast -> Color(0xFF4CAF50)
                    isCurrent -> Accent
                    else -> Color.LightGray
                },
                modifier = Modifier.padding(vertical = 3.dp)
            )
        }
    }
}

// ── Result Screen ─────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    result: CruxResult,
    getMessagesByIds: (List<Int>) -> List<Message>,
    onNew: () -> Unit
) {
    var dialogMessages by remember { mutableStateOf<List<Message>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Conversation Crux", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Accent,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                actions = {
                    TextButton(onClick = onNew) {
                        Text("New", color = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        val allEmpty = result.currentSituation.isEmpty() && result.decisions.isEmpty()
                && result.actions.isEmpty() && result.dates.isEmpty()
                && result.amounts.isEmpty() && result.openQuestions.isEmpty()
                && result.importantFacts.isEmpty()

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (allEmpty) {
                item {
                    Box(
                        modifier = Modifier.fillParentMaxSize().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Nothing important found in this conversation.",
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                cruxSection("CURRENTLY HAPPENING", result.currentSituation) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
                cruxSection("DECISIONS", result.decisions) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
                if (result.actions.isNotEmpty()) {
                    item { SectionHeader("ACTIONS") }
                    items(result.actions) { action ->
                        ActionRow(action) { ids -> dialogMessages = getMessagesByIds(ids) }
                    }
                }
                cruxSection("IMPORTANT DATES", result.dates) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
                cruxSection("IMPORTANT AMOUNTS", result.amounts) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
                cruxSection("OPEN QUESTIONS", result.openQuestions) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
                if (result.people.isNotEmpty()) {
                    item { SectionHeader("IMPORTANT PEOPLE") }
                    item { EntryText(result.people.joinToString(" · "), emptyList()) {} }
                }
                cruxSection("LINKS & FACTS", result.importantFacts) { ids ->
                    dialogMessages = getMessagesByIds(ids)
                }
            }

            // Debug bar
            item {
                val d = result.debugInfo
                Text(
                    text = "Debug: ${d.totalMessages} total → ${d.afterFilter} filtered → ${d.selectedMessages} selected (${d.timeRange})",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }
    }

    dialogMessages?.let { messages ->
        AlertDialog(
            onDismissRequest = { dialogMessages = null },
            title = { Text("Source messages") },
            text = {
                Text(
                    messages.joinToString("\n\n") { "[${it.sender}]: ${it.text}" },
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { dialogMessages = null }) { Text("Close") }
            }
        )
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

private fun androidx.compose.foundation.lazy.LazyListScope.cruxSection(
    title: String,
    cruxItems: List<CruxItem>,
    onTap: (List<Int>) -> Unit
) {
    if (cruxItems.isEmpty()) return
    item { SectionHeader(title) }
    items(cruxItems) { cruxItem ->
        EntryText(cruxItem.text, cruxItem.sourceMessageIds, onTap)
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = Accent,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun EntryText(text: String, sourceIds: List<Int>, onTap: (List<Int>) -> Unit) {
    val clickable = sourceIds.isNotEmpty()
    Text(
        text = "• $text",
        fontSize = 14.sp,
        color = Color(0xFF1F1F1F),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (clickable) Modifier.clickable { onTap(sourceIds) } else Modifier)
            .padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
private fun ActionRow(action: ActionItem, onTap: (List<Int>) -> Unit) {
    val label = if (action.person.isNotBlank()) "${action.person}: ${action.action}"
    else action.action
    EntryText(label, action.sourceMessageIds, onTap)
}
