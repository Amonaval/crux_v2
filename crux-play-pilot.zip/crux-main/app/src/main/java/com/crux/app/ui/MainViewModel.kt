package com.crux.app.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.crux.app.crux.CruxResult
import com.crux.app.crux.DebugInfo
import com.crux.app.crux.DeterministicCruxEngine
import com.crux.app.whatsapp.ContextReducer
import com.crux.app.whatsapp.Message
import com.crux.app.whatsapp.NoiseFilter
import com.crux.app.whatsapp.WhatsAppParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class UiState {
    object Idle : UiState()
    data class Processing(val stage: String) : UiState()
    data class Success(val result: CruxResult) : UiState()
    data class Error(val message: String) : UiState()
}

class MainViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _allMessages = MutableStateFlow<List<Message>>(emptyList())

    private val parser = WhatsAppParser()
    private val filter = NoiseFilter()
    private val reducer = ContextReducer(maxChars = 8_000)
    private val engine = DeterministicCruxEngine()

    fun processUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            runPipeline {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)
                        ?.bufferedReader(Charsets.UTF_8)
                        ?.readText()
                        ?: throw IllegalArgumentException("Cannot open file")
                }
            }
        }
    }

    fun processText(text: String) {
        viewModelScope.launch { runPipeline { text } }
    }

    fun loadSample(context: Context) {
        viewModelScope.launch {
            runPipeline {
                withContext(Dispatchers.IO) {
                    // Load only Sample 1 (up to the ===SAMPLE2=== marker)
                    val full = context.assets.open("sample_chat.txt")
                        .bufferedReader(Charsets.UTF_8)
                        .readText()
                    full.substringBefore("===SAMPLE2===").trim()
                }
            }
        }
    }

    fun reset() {
        _uiState.value = UiState.Idle
        _allMessages.value = emptyList()
    }

    fun getMessagesByIds(ids: List<Int>): List<Message> {
        val idSet = ids.toSet()
        return _allMessages.value.filter { it.id in idSet }
    }

    private suspend fun runPipeline(readContent: suspend () -> String) {
        try {
            _uiState.value = UiState.Processing("Reading conversation")
            val content = readContent()

            if (content.isBlank()) {
                _uiState.value = UiState.Error("File is empty")
                return
            }

            _uiState.value = UiState.Processing("Parsing messages")
            val parsed = withContext(Dispatchers.Default) { parser.parse(content) }

            if (parsed.isEmpty()) {
                _uiState.value = UiState.Error("No WhatsApp messages found.\nIs this a WhatsApp export?")
                return
            }

            _allMessages.value = parsed

            _uiState.value = UiState.Processing("Removing noise")
            val filtered = withContext(Dispatchers.Default) { filter.filter(parsed) }

            _uiState.value = UiState.Processing("Finding current context")
            val reduced = withContext(Dispatchers.Default) { reducer.reduce(filtered) }

            _uiState.value = UiState.Processing("Extracting Crux")
            val rawResult = withContext(Dispatchers.Default) { engine.process(reduced.messages) }

            val result = rawResult.copy(
                debugInfo = DebugInfo(
                    totalMessages = parsed.size,
                    afterFilter = filtered.size,
                    selectedMessages = reduced.messages.size,
                    timeRange = reduced.timeRange
                )
            )

            _uiState.value = UiState.Success(result)

        } catch (e: Exception) {
            _uiState.value = UiState.Error("Processing failed: ${e.message ?: "Unknown error"}")
        }
    }
}
