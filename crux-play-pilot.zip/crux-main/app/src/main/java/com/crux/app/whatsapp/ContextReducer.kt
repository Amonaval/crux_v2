package com.crux.app.whatsapp

import java.util.concurrent.TimeUnit

class ContextReducer(private val maxChars: Int = 8_000) {

    data class ReducerResult(
        val messages: List<Message>,
        val timeRange: String,
        val totalBefore: Int
    )

    private val WINDOWS = listOf(
        Pair(TimeUnit.HOURS.toMillis(24), "last 24 hours"),
        Pair(TimeUnit.DAYS.toMillis(3), "last 3 days"),
        Pair(TimeUnit.DAYS.toMillis(7), "last 7 days"),
        Pair(Long.MAX_VALUE / 2, "all available")
    )

    private val MINIMUM_MEANINGFUL = 5

    fun reduce(messages: List<Message>): ReducerResult {
        if (messages.isEmpty()) return ReducerResult(emptyList(), "empty", 0)
        val sorted = messages.sortedBy { it.timestamp }
        val latest = sorted.last().timestamp
        val total = sorted.size

        for ((windowMs, label) in WINDOWS) {
            val cutoff = if (windowMs == Long.MAX_VALUE / 2) 0L else latest - windowMs
            val windowed = sorted.filter { it.timestamp >= cutoff }
            if (windowed.size >= MINIMUM_MEANINGFUL || windowMs == Long.MAX_VALUE / 2) {
                val budgeted = applyCharBudget(windowed)
                return ReducerResult(budgeted, label, total)
            }
        }
        return ReducerResult(emptyList(), "none", total)
    }

    private fun applyCharBudget(messages: List<Message>): List<Message> {
        var chars = 0
        val result = mutableListOf<Message>()
        for (msg in messages.reversed()) {
            val cost = msg.text.length + msg.sender.length + 20
            if (chars + cost > maxChars && result.isNotEmpty()) break
            result.add(0, msg)
            chars += cost
        }
        return result
    }
}
