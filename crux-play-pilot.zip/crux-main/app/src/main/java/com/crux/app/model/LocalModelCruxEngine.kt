package com.crux.app.model

import com.crux.app.crux.CruxEngine
import com.crux.app.crux.CruxResult
import com.crux.app.crux.DeterministicCruxEngine
import com.crux.app.whatsapp.Message

/**
 * Stub for future llama.cpp / GGUF integration.
 *
 * To wire in a real model later:
 *   1. Add llama.cpp JNI bindings to app/build.gradle
 *   2. Load the .gguf model file from app's files/ directory in init()
 *   3. Set modelLoaded = true when successfully initialized
 *   4. Implement buildPrompt(messages) and parseModelResponse(json)
 *   5. Replace the fallback.process() call in process() with real inference
 */
class LocalModelCruxEngine(
    private val fallback: CruxEngine = DeterministicCruxEngine()
) : CruxEngine {

    private var modelLoaded = false

    fun isAvailable(): Boolean = modelLoaded

    override suspend fun process(messages: List<Message>): CruxResult {
        return if (isAvailable()) {
            runModelInference(messages) ?: fallback.process(messages)
        } else {
            fallback.process(messages)
        }
    }

    @Suppress("UNUSED_PARAMETER")
    private suspend fun runModelInference(messages: List<Message>): CruxResult? {
        // TODO: build prompt, call llama.cpp JNI, parse JSON response
        // Return null on any failure -> triggers fallback
        return null
    }
}
